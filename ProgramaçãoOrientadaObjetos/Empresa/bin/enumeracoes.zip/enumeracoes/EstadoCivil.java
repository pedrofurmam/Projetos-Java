package enumeracoes;

public enum EstadoCivil {
	SOLTEIRO,
    CASADO,
    DIVORCIADO,
    VIUVO

}
